package com.cookrecipes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookRecipesBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(CookRecipesBackendApplication.class, args);
    }
} 