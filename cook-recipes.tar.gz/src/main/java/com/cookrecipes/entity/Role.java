package com.cookrecipes.entity;
 
public enum Role {
    USER,
    ADMIN
} 