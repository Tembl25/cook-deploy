package com.cookrecipes.entity;

public enum RecipeCategory {
    BREAKFAST,
    LUNCH,
    DINNER,
    DESSERT,
    SNACK,
    VEGETARIAN,
    VEGAN,
    MEAT,
    FISH,
    SALAD,
    SOUP,
    PASTA,
    PIZZA,
    BAKING,
    DRINK
} 